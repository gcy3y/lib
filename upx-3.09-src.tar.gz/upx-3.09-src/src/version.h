#define UPX_VERSION_HEX         0x030900        /* 03.09.00 */
#define UPX_VERSION_STRING      "3.09"
#define UPX_VERSION_STRING4     "3.09"
#define UPX_VERSION_DATE        "Feb 18th 2013"
#define UPX_VERSION_DATE_ISO    "2013-02-18"
#define UPX_VERSION_YEAR        "2013"
